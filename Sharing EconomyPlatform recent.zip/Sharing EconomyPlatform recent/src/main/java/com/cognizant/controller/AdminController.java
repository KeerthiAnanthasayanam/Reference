package com.cognizant.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.AdminDao;

import com.cognizant.model.Admin;

@Controller
public class AdminController {
	@Autowired
	private AdminDao adminDaoImpl;
	
	@GetMapping("/adminlogin")
	public String customerLogin() {
		
		return "adminLogin";
	}
	@PostMapping("/Authentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model) {
	    Admin correct= adminDaoImpl.findByUsernameAndPassword(username, password);
		
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	System.out.println(session.getAttribute("username"));
	    	return "redirect:home";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "adminLogin";
	     }		
	}
	
	@GetMapping("/adminlogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:home";
	}

}
