package com.cognizant.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.VendorDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Vendor;

@Service
@Transactional
public class VendorDaoImpl {
	@Autowired
	private VendorDao vendorDao;
	
	public void save(Vendor vendor) {
		vendorDao.save(vendor);		
	}
	public Vendor findByUsernameAndPassword(String username, String password) {
		// TODO Auto-generated method stub
		return vendorDao.findByEmailAndPassword(username, password);
	}


}
