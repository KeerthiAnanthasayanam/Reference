/*package com.cognizant.dao.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.dao.CustomerDao;
import com.cognizant.model.Admin;
import com.cognizant.model.Customer;
@Service
@Transactional
public class AdminDaoImpl {
	@Autowired
	private AdminDao adminDao;
	
	
	public Admin findByUsernameAndPassword(String username, String password) {
		// TODO Auto-generated method stub
		return adminDao.findByUsernameAndPassword(username, password);
	}


}*/
